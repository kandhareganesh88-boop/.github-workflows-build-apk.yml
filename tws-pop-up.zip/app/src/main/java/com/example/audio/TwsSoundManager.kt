package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class TwsSoundManager(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var chirpJob: Job? = null

    /**
     * Light haptic pop for case clicks and toggles
     */
    fun performHapticClick() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(25)
            }
        } catch (_: Exception) {}
    }

    /**
     * Double haptic for connection confirmed
     */
    fun performHapticSuccess() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 35, 80, 45)
                val amplitudes = intArrayOf(0, 180, 0, 255)
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(100)
            }
        } catch (_: Exception) {}
    }

    /**
     * Plays a pleasant ascending dual-tone chime when Fast Pair connects
     */
    fun playConnectChime(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            playTone(587.33, 120) // D5
            delay(50)
            playTone(880.0, 180)  // A5
        }
    }

    /**
     * Plays pulsing radar chirps for "Find My Earbuds"
     */
    fun startFindMyBudsChirp(scope: CoroutineScope, onPulsed: () -> Unit = {}) {
        stopFindMyBudsChirp()
        chirpJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                onPulsed()
                performHapticClick()
                playTone(1760.0, 90) // High A6 chirp
                delay(80)
                playTone(2637.0, 140) // High E7 chirp
                delay(800)
            }
        }
    }

    fun stopFindMyBudsChirp() {
        chirpJob?.cancel()
        chirpJob = null
    }

    private fun playTone(freqHz: Double, durationMs: Int) {
        try {
            val sampleRate = 44100
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val generatedSnd = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                // Sine wave with smooth fade in / fade out envelope to avoid audio clicks
                val envelope = when {
                    i < 200 -> i / 200.0
                    i > numSamples - 200 -> (numSamples - i) / 200.0
                    else -> 1.0
                }
                val sample = sin(2.0 * PI * i.toDouble() / (sampleRate / freqHz)) * envelope
                generatedSnd[i] = (sample * 0.7 * Short.MAX_VALUE).toInt().toShort()
            }

            val bufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(bufferSize, generatedSnd.size * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(generatedSnd, 0, generatedSnd.size)
            audioTrack.play()
            Thread.sleep(durationMs.toLong() + 20)
            audioTrack.release()
        } catch (_: Exception) {}
    }
}
