package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.HearingDisabled
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.AncMode
import com.example.model.TwsDevice
import com.example.model.TwsModelType
import com.example.ui.components.TwsBatteryBarPill
import com.example.ui.components.TwsCircularBatteryGauge
import com.example.ui.components.TwsFastPairModal
import com.example.ui.components.TwsInteractiveEarbudsCanvas
import com.example.ui.components.TwsRadarScanner
import com.example.ui.components.TwsSoundwaveVisualizer
import com.example.ui.components.getBatteryColor
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.IndigoAccent
import com.example.ui.viewmodel.TwsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TwsMainScreen(
    viewModel: TwsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeDevice by viewModel.activeDevice.collectAsState()
    val showPopup by viewModel.showFastPairPopup.collectAsState()
    val popupDevice by viewModel.popupDevice.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isFindingChirpActive by viewModel.isFindingChirpActive.collectAsState()

    var showBatteryTuner by remember { mutableStateOf(false) }

    // Permission launcher for Bluetooth
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.startScanning()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (activeDevice.isConnected) BatteryGreen else Color.Gray)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TWS Pop-up",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                },
                actions = {
                    // Trigger popup preview button
                    IconButton(
                        onClick = { viewModel.triggerPopupForDevice(activeDevice) },
                        modifier = Modifier.testTag("trigger_popup_preview_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sensors,
                            contentDescription = "Test Pop-up",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    // Header Status & Fast Pair Pop-up Trigger Banner
                    FastPairBanner(
                        onTriggerPopup = { viewModel.triggerPopupForDevice(activeDevice) },
                        onScanNearby = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val hasScan = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                                val hasConnect = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                                if (!hasScan || !hasConnect) {
                                    permissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT))
                                } else {
                                    viewModel.startScanning()
                                }
                            } else {
                                viewModel.startScanning()
                            }
                        },
                        isScanning = isScanning
                    )
                }

                // 1. Paired Earbuds Interactive Card
                item {
                    PairedEarbudsInteractiveCard(
                        device = activeDevice,
                        onToggleCase = { viewModel.toggleCaseLid() },
                        onToggleLeft = { viewModel.toggleEarbudPlacement(isLeft = true) },
                        onToggleRight = { viewModel.toggleEarbudPlacement(isLeft = false) },
                        onToggleChargingLeft = { viewModel.toggleChargingState("left") },
                        onToggleChargingRight = { viewModel.toggleChargingState("right") },
                        onToggleChargingCase = { viewModel.toggleChargingState("case") },
                        onOpenBatteryTuner = { showBatteryTuner = !showBatteryTuner }
                    )
                }

                // 2. Battery Slider Tuner (Expandable)
                if (showBatteryTuner) {
                    item {
                        BatteryTunerCard(
                            device = activeDevice,
                            onValuesChanged = { l, r, c ->
                                viewModel.updateBatterySliders(l, r, c)
                            }
                        )
                    }
                }

                // 3. Noise Cancellation (ANC / Transparency / Off)
                item {
                    NoiseControlCard(
                        currentMode = activeDevice.ancMode,
                        onModeSelected = { viewModel.setAncMode(it) }
                    )
                }

                // 4. Quick Tools: Find My Buds & Equalizer
                item {
                    QuickToolsRow(
                        isFindingChirpActive = isFindingChirpActive,
                        onToggleFind = { viewModel.toggleFindMyBuds() },
                        activeEq = activeDevice.eqPreset,
                        onEqSelected = { viewModel.setEqPreset(it) }
                    )
                }

                // 5. Earbuds Model Style Switcher
                item {
                    ModelStyleSelector(
                        selected = activeDevice.modelType,
                        onSelect = { viewModel.switchActiveModel(it) }
                    )
                }

                // 6. Nearby TWS Finder / Radar Section
                item {
                    NearbyFinderSection(
                        isScanning = isScanning,
                        discoveredDevices = discoveredDevices,
                        onStartScan = { viewModel.startScanning() },
                        onDeviceSelected = { viewModel.triggerPopupForDevice(it) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // The signature Fast Pair Pop-Up modal requested by the user!
            TwsFastPairModal(
                device = popupDevice,
                isVisible = showPopup,
                onDismiss = { viewModel.dismissPopup() },
                onConnectSuccess = { connectedDevice ->
                    viewModel.onConnectDevice(connectedDevice)
                },
                onPlayChime = {
                    viewModel.playConnectChime()
                }
            )
        }
    }
}

@Composable
private fun FastPairBanner(
    onTriggerPopup: () -> Unit,
    onScanNearby: () -> Unit,
    isScanning: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("fast_pair_banner"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.BluetoothSearching,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "TWS Device Finder",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isScanning) "Scanning nearby for earbuds..." else "Tap to trigger TWS Pop-up",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onScanNearby,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("scan_nearby_btn")
                ) {
                    Text(
                        text = if (isScanning) "Scanning..." else "Scan",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PairedEarbudsInteractiveCard(
    device: TwsDevice,
    onToggleCase: () -> Unit,
    onToggleLeft: () -> Unit,
    onToggleRight: () -> Unit,
    onToggleChargingLeft: () -> Unit,
    onToggleChargingRight: () -> Unit,
    onToggleChargingCase: () -> Unit,
    onOpenBatteryTuner: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("paired_earbuds_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Card Header: Device Name, Connection Status & Tune Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = device.name,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(BatteryGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Connected • ${if (device.isCaseOpen) "Case Open" else "Case Closed"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onOpenBatteryTuner,
                    modifier = Modifier.testTag("tune_battery_btn")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Tune,
                        contentDescription = "Tune battery",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Interactive 3D Earbuds Canvas
            TwsInteractiveEarbudsCanvas(
                device = device,
                isOpen = device.isCaseOpen,
                onToggleCase = onToggleCase,
                onToggleLeftEarbud = onToggleLeft,
                onToggleRightEarbud = onToggleRight,
                height = 210.dp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3-Way Battery Status Section: Left, Case, Right
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Earbud Gauge
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable(onClick = onToggleChargingLeft)
                    ) {
                        TwsCircularBatteryGauge(
                            level = device.leftBattery,
                            isCharging = device.leftCharging,
                            label = "Left Bud",
                            size = 68.dp
                        )
                        Text(
                            text = if (device.leftCharging) "Charging" else (if (device.isLeftInEar) "In Ear" else "In Case"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            fontSize = 10.sp
                        )
                    }

                    // Case Gauge
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable(onClick = onToggleChargingCase)
                    ) {
                        TwsCircularBatteryGauge(
                            level = device.caseBattery,
                            isCharging = device.caseCharging,
                            label = "Case",
                            size = 68.dp
                        )
                        Text(
                            text = if (device.caseCharging) "Charging" else "+24h Playtime",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            fontSize = 10.sp
                        )
                    }

                    // Right Earbud Gauge
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable(onClick = onToggleChargingRight)
                    ) {
                        TwsCircularBatteryGauge(
                            level = device.rightBattery,
                            isCharging = device.rightCharging,
                            label = "Right Bud",
                            size = 68.dp
                        )
                        Text(
                            text = if (device.rightCharging) "Charging" else (if (device.isRightInEar) "In Ear" else "In Case"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BatteryTunerCard(
    device: TwsDevice,
    onValuesChanged: (left: Int, right: Int, case: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Interactive Battery Simulation",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Adjust sliders to test battery status and color transitions in real-time.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Left slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "L: ${device.leftBattery}%",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.width(60.dp)
                )
                Slider(
                    value = device.leftBattery.toFloat(),
                    onValueChange = { onValuesChanged(it.toInt(), device.rightBattery, device.caseBattery) },
                    valueRange = 0f..100f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = getBatteryColor(device.leftBattery, device.leftCharging),
                        activeTrackColor = getBatteryColor(device.leftBattery, device.leftCharging)
                    )
                )
            }

            // Case slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Case: ${device.caseBattery}%",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.width(60.dp)
                )
                Slider(
                    value = device.caseBattery.toFloat(),
                    onValueChange = { onValuesChanged(device.leftBattery, device.rightBattery, it.toInt()) },
                    valueRange = 0f..100f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = getBatteryColor(device.caseBattery, device.caseCharging),
                        activeTrackColor = getBatteryColor(device.caseBattery, device.caseCharging)
                    )
                )
            }

            // Right slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "R: ${device.rightBattery}%",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.width(60.dp)
                )
                Slider(
                    value = device.rightBattery.toFloat(),
                    onValueChange = { onValuesChanged(device.leftBattery, it.toInt(), device.caseBattery) },
                    valueRange = 0f..100f,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = getBatteryColor(device.rightBattery, device.rightCharging),
                        activeTrackColor = getBatteryColor(device.rightBattery, device.rightCharging)
                    )
                )
            }
        }
    }
}

@Composable
private fun NoiseControlCard(
    currentMode: AncMode,
    onModeSelected: (AncMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Noise Control",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = currentMode.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Live animated soundwave visualizer
                TwsSoundwaveVisualizer(
                    ancMode = currentMode,
                    width = 90.dp,
                    height = 24.dp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Segmented mode selector
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    AncModeOption(
                        title = "ANC",
                        icon = Icons.Default.HearingDisabled,
                        isSelected = currentMode == AncMode.ANC,
                        onClick = { onModeSelected(AncMode.ANC) },
                        modifier = Modifier.weight(1f)
                    )
                    AncModeOption(
                        title = "Off",
                        icon = Icons.Default.PowerSettingsNew,
                        isSelected = currentMode == AncMode.OFF,
                        onClick = { onModeSelected(AncMode.OFF) },
                        modifier = Modifier.weight(1f)
                    )
                    AncModeOption(
                        title = "Ambient",
                        icon = Icons.Default.Hearing,
                        isSelected = currentMode == AncMode.TRANSPARENCY,
                        onClick = { onModeSelected(AncMode.TRANSPARENCY) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun AncModeOption(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedBg by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
        label = "ancBg"
    )
    val animatedTextColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "ancText"
    )

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = animatedBg,
        modifier = modifier
            .padding(horizontal = 2.dp)
            .height(44.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = animatedTextColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = animatedTextColor
            )
        }
    }
}

@Composable
private fun QuickToolsRow(
    isFindingChirpActive: Boolean,
    onToggleFind: () -> Unit,
    activeEq: String,
    onEqSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Find My Earbuds Tool
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onToggleFind),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isFindingChirpActive) CyanPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
            ),
            border = BorderStroke(
                1.dp,
                if (isFindingChirpActive) CyanPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = if (isFindingChirpActive) CyanPrimary else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Find My Buds",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isFindingChirpActive) "Chirping sound..." else "Play radar chime",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Sound Equalizer preset toggle
        val presets = listOf("Balanced", "Bass Boost", "Spatial")
        Card(
            modifier = Modifier
                .weight(1f)
                .clickable {
                    val next = presets[(presets.indexOf(activeEq) + 1) % presets.size]
                    onEqSelected(next)
                },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = IndigoAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Sound EQ",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = activeEq,
                    style = MaterialTheme.typography.bodySmall,
                    color = IndigoAccent
                )
            }
        }
    }
}

@Composable
private fun ModelStyleSelector(
    selected: TwsModelType,
    onSelect: (TwsModelType) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Earbuds Model Edition",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(TwsModelType.values()) { model ->
                FilterChip(
                    selected = model == selected,
                    onClick = { onSelect(model) },
                    label = { Text(model.displayName, fontSize = 12.sp) },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }
    }
}

@Composable
private fun NearbyFinderSection(
    isScanning: Boolean,
    discoveredDevices: List<TwsDevice>,
    onStartScan: () -> Unit,
    onDeviceSelected: (TwsDevice) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Nearby TWS Devices",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Tap any device to trigger Fast Pair pop-up",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Radar,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (isScanning) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    TwsRadarScanner(
                        isScanning = true,
                        size = 140.dp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Devices list
            discoveredDevices.forEach { device ->
                DiscoveredDeviceRow(
                    device = device,
                    onClick = { onDeviceSelected(device) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun DiscoveredDeviceRow(
    device: TwsDevice,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("discovered_device_${device.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bluetooth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = device.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${device.modelType.brand} • Signal ${device.rssi} dBm",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Battery preview pill
            TwsBatteryBarPill(
                level = device.leftBattery,
                isCharging = device.leftCharging,
                label = "L"
            )
        }
    }
}
