package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors - Sleek modern audio aesthetic
val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryDark = Color(0xFF00B4D8)
val IndigoAccent = Color(0xFF6366F1)
val ElectricViolet = Color(0xFF8B5CF6)

// Surface & Background - Deep obsidian & slate
val DarkBackground = Color(0xFF0B0F17)
val DarkSurface = Color(0xFF131A26)
val DarkSurfaceElevated = Color(0xFF1E2838)
val DarkSurfaceBorder = Color(0xFF2A364B)

// Light Theme equivalents
val LightBackground = Color(0xFFF6F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEDF2F7)
val LightSurfaceBorder = Color(0xFFE2E8F0)

// Battery status colors
val BatteryGreen = Color(0xFF10B981)
val BatteryGreenGlow = Color(0x6610B981)
val BatteryAmber = Color(0xFFF59E0B)
val BatteryAmberGlow = Color(0x66F59E0B)
val BatteryRed = Color(0xFFEF4444)
val BatteryRedGlow = Color(0x66EF4444)
val BatteryChargingCyan = Color(0xFF00E5FF)

// Text and icons
val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextTertiaryDark = Color(0xFF6B7280)

val TextPrimaryLight = Color(0xFF111827)
val TextSecondaryLight = Color(0xFF4B5563)
val TextTertiaryLight = Color(0xFF9CA3AF)
