package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TwsDevice
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class ConnectState {
    IDLE,
    CONNECTING,
    CONNECTED
}

@Composable
fun TwsFastPairModal(
    device: TwsDevice?,
    isVisible: Boolean,
    onDismiss: () -> Unit,
    onConnectSuccess: (TwsDevice) -> Unit,
    onPlayChime: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (device == null) return

    val scope = rememberCoroutineScope()
    var connectState by remember(device.id) { mutableStateOf(ConnectState.IDLE) }
    var isCaseLidOpen by remember(device.id) { mutableStateOf(true) }
    var leftInEar by remember(device.id) { mutableStateOf(device.isLeftInEar) }
    var rightInEar by remember(device.id) { mutableStateOf(device.isRightInEar) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulseRadar")
    val radarRing by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarRing"
    )

    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn(tween(250)),
        exit = fadeOut(tween(200))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = isVisible,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    )
                ),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = tween(220)
                )
            ) {
                Surface(
                    modifier = modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 16.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {} // prevent dismissing when tapping modal card
                        )
                        .testTag("fast_pair_popup_card"),
                    shape = RoundedCornerShape(32.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 12.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp, bottom = 24.dp, start = 20.dp, end = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Top Drag Pill Handle
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Header Bar: Device found status & Close button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BluetoothSearching,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (connectState == ConnectState.CONNECTED) "Paired & Connected" else "Nearby TWS Detected",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("dismiss_popup_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Device Title and Subtitle
                        Text(
                            text = device.name,
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${device.modelType.brand} • Tap case to open/close",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Interactive Earbuds Visualizer Canvas with surrounding radar pulse
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                        ) {
                            // Radar wave background
                            Canvas(modifier = Modifier.size(200.dp)) {
                                val centerOffset = Offset(size.width / 2f, size.height / 2f)
                                val maxRadius = size.minDimension / 2f

                                val ring1Radius = maxRadius * radarRing
                                val ring1Alpha = (1f - radarRing).coerceIn(0f, 0.4f)
                                drawCircle(
                                    color = CyanPrimary.copy(alpha = ring1Alpha),
                                    radius = ring1Radius,
                                    center = centerOffset,
                                    style = Stroke(width = 3f)
                                )

                                val ring2Progress = (radarRing + 0.5f) % 1f
                                val ring2Radius = maxRadius * ring2Progress
                                val ring2Alpha = (1f - ring2Progress).coerceIn(0f, 0.3f)
                                drawCircle(
                                    color = CyanPrimary.copy(alpha = ring2Alpha),
                                    radius = ring2Radius,
                                    center = centerOffset,
                                    style = Stroke(width = 2f)
                                )
                            }

                            // Interactive Earbuds & Case
                            TwsInteractiveEarbudsCanvas(
                                device = device.copy(
                                    isLeftInEar = leftInEar,
                                    isRightInEar = rightInEar
                                ),
                                isOpen = isCaseLidOpen,
                                onToggleCase = { isCaseLidOpen = !isCaseLidOpen },
                                onToggleLeftEarbud = { leftInEar = !leftInEar },
                                onToggleRightEarbud = { rightInEar = !rightInEar },
                                height = 190.dp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Battery Status Rings: Left, Case, Right
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Left Earbud
                                TwsCircularBatteryGauge(
                                    level = device.leftBattery,
                                    isCharging = device.leftCharging,
                                    label = "Left Bud",
                                    size = 64.dp
                                )

                                // Charging Case
                                TwsCircularBatteryGauge(
                                    level = device.caseBattery,
                                    isCharging = device.caseCharging,
                                    label = "Case",
                                    size = 64.dp
                                )

                                // Right Earbud
                                TwsCircularBatteryGauge(
                                    level = device.rightBattery,
                                    isCharging = device.rightCharging,
                                    label = "Right Bud",
                                    size = 64.dp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Connect / Action Buttons
                        when (connectState) {
                            ConnectState.IDLE -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onDismiss,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(50.dp)
                                            .testTag("popup_cancel_btn"),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Text("Not Now")
                                    }

                                    Button(
                                        onClick = {
                                            connectState = ConnectState.CONNECTING
                                            scope.launch {
                                                delay(1200)
                                                connectState = ConnectState.CONNECTED
                                                onPlayChime()
                                                delay(900)
                                                onConnectSuccess(device)
                                            }
                                        },
                                        modifier = Modifier
                                            .weight(1.4f)
                                            .height(50.dp)
                                            .testTag("popup_connect_btn"),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Headphones,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Connect",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            ConnectState.CONNECTING -> {
                                Button(
                                    onClick = {},
                                    enabled = false,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        strokeWidth = 2.5.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "Connecting to ${device.name}...",
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            ConnectState.CONNECTED -> {
                                Button(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("popup_connected_btn"),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BatteryGreen,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Connected Successfully",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
