package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.AncMode
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.IndigoAccent

@Composable
fun TwsSoundwaveVisualizer(
    ancMode: AncMode,
    modifier: Modifier = Modifier,
    barCount: Int = 16,
    width: Dp = 120.dp,
    height: Dp = 28.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "soundwave")

    val wave1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave1"
    )

    val wave2 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 620, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave2"
    )

    val wave3 by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave3"
    )

    Canvas(
        modifier = modifier
            .width(width)
            .height(height)
    ) {
        val canvasW = size.width
        val canvasH = size.height
        val barWidth = canvasW / (barCount * 1.6f)
        val gap = (canvasW - (barWidth * barCount)) / (barCount - 1).coerceAtLeast(1)

        val activeFactor = when (ancMode) {
            AncMode.ANC -> 0.35f // Dampened waveform
            AncMode.TRANSPARENCY -> 0.95f // Dynamic ambient sound
            AncMode.OFF -> 0.6f // Standard sound
        }

        for (i in 0 until barCount) {
            val wavePhase = when (i % 3) {
                0 -> wave1
                1 -> wave2
                else -> wave3
            }
            // Curve envelope
            val envelope = kotlin.math.sin((i.toFloat() / barCount.toFloat()) * kotlin.math.PI).toFloat()
            val barHeight = ((wavePhase * envelope * activeFactor) * canvasH).coerceIn(4f, canvasH)

            val x = i * (barWidth + gap)
            val y = (canvasH - barHeight) / 2f

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(CyanPrimary, IndigoAccent, ElectricViolet),
                    startY = y,
                    endY = y + barHeight
                ),
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
