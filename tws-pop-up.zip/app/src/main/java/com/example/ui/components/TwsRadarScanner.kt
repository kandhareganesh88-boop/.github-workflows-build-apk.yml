package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanPrimary

@Composable
fun TwsRadarScanner(
    isScanning: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radarRotation")

    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweepAngle"
    )

    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    Canvas(modifier = modifier.size(size)) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val maxRadius = this.size.minDimension / 2f

        // Concentric radar circles
        val circles = listOf(0.33f, 0.66f, 1f)
        circles.forEach { ratio ->
            drawCircle(
                color = CyanPrimary.copy(alpha = 0.15f),
                radius = maxRadius * ratio,
                center = center,
                style = Stroke(width = 1.5f)
            )
        }

        // Crosshairs
        drawLine(
            color = CyanPrimary.copy(alpha = 0.12f),
            start = Offset(center.x, center.y - maxRadius),
            end = Offset(center.x, center.y + maxRadius),
            strokeWidth = 1f
        )
        drawLine(
            color = CyanPrimary.copy(alpha = 0.12f),
            start = Offset(center.x - maxRadius, center.y),
            end = Offset(center.x + maxRadius, center.y),
            strokeWidth = 1f
        )

        // Pulsing radio wave
        if (isScanning) {
            val waveAlpha = (1f - pulseRadius).coerceIn(0f, 0.45f)
            drawCircle(
                color = CyanPrimary.copy(alpha = waveAlpha),
                radius = maxRadius * pulseRadius,
                center = center,
                style = Stroke(width = 2.5f)
            )

            // Rotating sweep beam
            rotate(degrees = sweepAngle, pivot = center) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Transparent,
                            CyanPrimary.copy(alpha = 0.4f)
                        ),
                        center = center
                    ),
                    startAngle = 0f,
                    sweepAngle = 75f,
                    useCenter = true,
                    topLeft = Offset(center.x - maxRadius, center.y - maxRadius),
                    size = androidx.compose.ui.geometry.Size(maxRadius * 2, maxRadius * 2)
                )
            }
        }

        // Radar center dot
        drawCircle(
            color = CyanPrimary,
            radius = 4f,
            center = center
        )
    }
}
