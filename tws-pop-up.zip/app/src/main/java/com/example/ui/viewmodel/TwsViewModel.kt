package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TwsSoundManager
import com.example.bluetooth.TwsBluetoothManager
import com.example.data.TwsDatabase
import com.example.data.TwsDeviceEntity
import com.example.model.AncMode
import com.example.model.TwsDevice
import com.example.model.TwsModelType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TwsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TwsDatabase.getDatabase(application)
    private val dao = db.twsDao()
    val soundManager = TwsSoundManager(application)
    val bluetoothManager = TwsBluetoothManager(application)

    // Current paired active device
    private val _activeDevice = MutableStateFlow(
        TwsDevice(
            id = "DEFAULT-AIRPODS-PRO",
            name = "AirPods Pro (2nd Gen)",
            modelType = TwsModelType.STEM_WHITE,
            leftBattery = 88,
            leftCharging = false,
            rightBattery = 85,
            rightCharging = false,
            caseBattery = 74,
            caseCharging = true,
            isCaseOpen = true,
            isLeftInEar = false,
            isRightInEar = false,
            isConnected = true,
            isPaired = true,
            rssi = -38,
            ancMode = AncMode.ANC,
            eqPreset = "Balanced"
        )
    )
    val activeDevice: StateFlow<TwsDevice> = _activeDevice.asStateFlow()

    // Pop-up modal visibility & device
    private val _showFastPairPopup = MutableStateFlow(false)
    val showFastPairPopup: StateFlow<Boolean> = _showFastPairPopup.asStateFlow()

    private val _popupDevice = MutableStateFlow<TwsDevice?>(null)
    val popupDevice: StateFlow<TwsDevice?> = _popupDevice.asStateFlow()

    // Scanner
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    val discoveredDevices: StateFlow<List<TwsDevice>> = bluetoothManager.discoveredDevices

    // Find My Earbuds state
    private val _isFindingChirpActive = MutableStateFlow(false)
    val isFindingChirpActive: StateFlow<Boolean> = _isFindingChirpActive.asStateFlow()

    init {
        loadPersistedDevice()
        bluetoothManager.refreshDevices()
    }

    private fun loadPersistedDevice() {
        viewModelScope.launch {
            dao.getAllPairedDevices().collect { list ->
                if (list.isNotEmpty()) {
                    val entity = list.first()
                    _activeDevice.value = entity.toDomain()
                } else {
                    // Seed initial paired device
                    dao.upsertDevice(TwsDeviceEntity.fromDomain(_activeDevice.value))
                }
            }
        }
    }

    fun triggerPopupForDevice(device: TwsDevice) {
        soundManager.performHapticClick()
        _popupDevice.value = device
        _showFastPairPopup.value = true
    }

    fun dismissPopup() {
        _showFastPairPopup.value = false
        _popupDevice.value = null
    }

    fun onConnectDevice(device: TwsDevice) {
        val updated = device.copy(
            isConnected = true,
            isPaired = true,
            isCaseOpen = true
        )
        _activeDevice.value = updated
        soundManager.performHapticSuccess()
        soundManager.playConnectChime(viewModelScope)
        viewModelScope.launch {
            dao.upsertDevice(TwsDeviceEntity.fromDomain(updated))
            delay(500)
            dismissPopup()
        }
    }

    fun toggleCaseLid() {
        soundManager.performHapticClick()
        val current = _activeDevice.value
        val newState = !current.isCaseOpen
        _activeDevice.value = current.copy(isCaseOpen = newState)
    }

    fun toggleEarbudPlacement(isLeft: Boolean) {
        soundManager.performHapticClick()
        val current = _activeDevice.value
        _activeDevice.value = if (isLeft) {
            current.copy(isLeftInEar = !current.isLeftInEar)
        } else {
            current.copy(isRightInEar = !current.isRightInEar)
        }
    }

    fun toggleChargingState(target: String) {
        soundManager.performHapticClick()
        val current = _activeDevice.value
        _activeDevice.value = when (target) {
            "left" -> current.copy(leftCharging = !current.leftCharging)
            "right" -> current.copy(rightCharging = !current.rightCharging)
            "case" -> current.copy(caseCharging = !current.caseCharging)
            else -> current
        }
    }

    fun updateBatterySliders(left: Int, right: Int, case: Int) {
        val current = _activeDevice.value
        _activeDevice.value = current.copy(
            leftBattery = left.coerceIn(0, 100),
            rightBattery = right.coerceIn(0, 100),
            caseBattery = case.coerceIn(0, 100)
        )
    }

    fun setAncMode(mode: AncMode) {
        soundManager.performHapticClick()
        _activeDevice.value = _activeDevice.value.copy(ancMode = mode)
        viewModelScope.launch {
            dao.upsertDevice(TwsDeviceEntity.fromDomain(_activeDevice.value))
        }
    }

    fun setEqPreset(preset: String) {
        soundManager.performHapticClick()
        _activeDevice.value = _activeDevice.value.copy(eqPreset = preset)
        viewModelScope.launch {
            dao.upsertDevice(TwsDeviceEntity.fromDomain(_activeDevice.value))
        }
    }

    fun startScanning() {
        soundManager.performHapticClick()
        _isScanning.value = true
        bluetoothManager.refreshDevices()
        viewModelScope.launch {
            delay(3200)
            _isScanning.value = false
            // Auto trigger pop-up for the top discovered device to showcase the requested feature!
            val topDevice = bluetoothManager.discoveredDevices.value.firstOrNull { it.id != _activeDevice.value.id }
                ?: bluetoothManager.getSimulatedFastPairDevices().first()
            triggerPopupForDevice(topDevice)
        }
    }

    fun stopScanning() {
        _isScanning.value = false
    }

    fun toggleFindMyBuds() {
        soundManager.performHapticClick()
        if (_isFindingChirpActive.value) {
            soundManager.stopFindMyBudsChirp()
            _isFindingChirpActive.value = false
        } else {
            _isFindingChirpActive.value = true
            soundManager.startFindMyBudsChirp(viewModelScope)
        }
    }

    fun playConnectChime() {
        soundManager.playConnectChime(viewModelScope)
    }

    fun switchActiveModel(modelType: TwsModelType) {
        soundManager.performHapticClick()
        val current = _activeDevice.value
        val newName = when (modelType) {
            TwsModelType.STEM_WHITE -> "AirPods Pro"
            TwsModelType.IN_EAR_ROUND_DARK -> "Pixel Buds Pro"
            TwsModelType.NEON_CYAN -> "Cyber Gaming TWS"
            TwsModelType.TRANSPARENT_GLAS -> "Nothing Ear (2)"
            TwsModelType.GRAPHITE_OVAL -> "Galaxy Buds2 Pro"
        }
        val updated = current.copy(
            name = newName,
            modelType = modelType
        )
        _activeDevice.value = updated
        viewModelScope.launch {
            dao.upsertDevice(TwsDeviceEntity.fromDomain(updated))
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.stopFindMyBudsChirp()
        bluetoothManager.cleanUp()
    }
}
