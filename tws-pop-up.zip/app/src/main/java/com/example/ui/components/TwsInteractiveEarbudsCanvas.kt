package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TwsDevice
import com.example.model.TwsModelType
import com.example.ui.theme.BatteryAmber
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.BatteryRed
import com.example.ui.theme.CyanPrimary

@Composable
fun TwsInteractiveEarbudsCanvas(
    device: TwsDevice,
    isOpen: Boolean,
    onToggleCase: () -> Unit,
    onToggleLeftEarbud: () -> Unit,
    onToggleRightEarbud: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 230.dp
) {
    // Lid open/close animation
    val lidProgress by animateFloatAsState(
        targetValue = if (isOpen) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "lidProgress"
    )

    // Left earbud undock offset
    val leftLiftProgress by animateFloatAsState(
        targetValue = when {
            device.isLeftInEar -> 1f
            isOpen -> 0.35f
            else -> 0f
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "leftLift"
    )

    // Right earbud undock offset
    val rightLiftProgress by animateFloatAsState(
        targetValue = when {
            device.isRightInEar -> 1f
            isOpen -> 0.35f
            else -> 0f
        },
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "rightLift"
    )

    // Breathing glow animation for case status LED
    val infiniteTransition = rememberInfiniteTransition(label = "breathe")
    val ledPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ledPulse"
    )

    // Gentle hover float for floating earbuds
    val hoverOffset by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hoverOffset"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_earbuds_container"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onToggleCase
                ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .size(width = 300.dp, height = height)
                    .testTag("earbuds_canvas")
            ) {
                val canvasW = size.width
                val canvasH = size.height
                val centerX = canvasW / 2f
                val caseCenterY = canvasH * 0.62f

                // Color palette according to ModelType
                val (caseBaseColor, caseAccentColor, budBodyColor, budAccent) = getDeviceColors(device.modelType)

                // 1. Draw Case Shadow
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent),
                        center = Offset(centerX, canvasH * 0.92f),
                        radius = 110f
                    ),
                    topLeft = Offset(centerX - 95f, canvasH * 0.88f),
                    size = Size(190f, 28f)
                )

                // 2. Earbuds (Drawn behind the case front wall, but in front of case interior)
                val leftBudX = centerX - 42f
                val rightBudX = centerX + 42f

                // Left Earbud
                val leftLiftY = caseCenterY - (leftLiftProgress * 75f) + (if (device.isLeftInEar) hoverOffset else 0f)
                val leftTilt = if (device.isLeftInEar) -14f else 0f
                rotate(degrees = leftTilt, pivot = Offset(leftBudX, leftLiftY)) {
                    drawSingleEarbud(
                        centerX = leftBudX,
                        centerY = leftLiftY,
                        isLeft = true,
                        modelType = device.modelType,
                        bodyColor = budBodyColor,
                        accentColor = budAccent,
                        isCharging = device.leftCharging && isOpen.not()
                    )
                }

                // Right Earbud
                val rightLiftY = caseCenterY - (rightLiftProgress * 75f) + (if (device.isRightInEar) hoverOffset else 0f)
                val rightTilt = if (device.isRightInEar) 14f else 0f
                rotate(degrees = rightTilt, pivot = Offset(rightBudX, rightLiftY)) {
                    drawSingleEarbud(
                        centerX = rightBudX,
                        centerY = rightLiftY,
                        isLeft = false,
                        modelType = device.modelType,
                        bodyColor = budBodyColor,
                        accentColor = budAccent,
                        isCharging = device.rightCharging && isOpen.not()
                    )
                }

                // 3. Draw Case Lower Body (Front)
                val caseWidth = 176f
                val caseHeight = 114f
                val caseLeft = centerX - (caseWidth / 2f)
                val caseTop = caseCenterY - 26f

                // Case Body outer rounded rect
                val bodyPath = Path().apply {
                    addRoundRect(
                        RoundRect(
                            rect = androidx.compose.ui.geometry.Rect(
                                left = caseLeft,
                                top = caseTop,
                                right = caseLeft + caseWidth,
                                bottom = caseTop + caseHeight
                            ),
                            topLeft = CornerRadius(28f, 28f),
                            topRight = CornerRadius(28f, 28f),
                            bottomLeft = CornerRadius(46f, 46f),
                            bottomRight = CornerRadius(46f, 46f)
                        )
                    )
                }

                // Case Body Gradient fill
                drawPath(
                    path = bodyPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            caseAccentColor,
                            caseBaseColor,
                            caseBaseColor.copy(alpha = 0.95f)
                        ),
                        startY = caseTop,
                        endY = caseTop + caseHeight
                    )
                )

                // Inner charging cradle bay shadow cutouts (visible when lid is open)
                if (lidProgress > 0.05f) {
                    val bayRadiusX = 22f
                    val bayRadiusY = 16f
                    drawOval(
                        color = Color.Black.copy(alpha = 0.55f * lidProgress),
                        topLeft = Offset(leftBudX - bayRadiusX, caseTop + 4f),
                        size = Size(bayRadiusX * 2, bayRadiusY * 2)
                    )
                    drawOval(
                        color = Color.Black.copy(alpha = 0.55f * lidProgress),
                        topLeft = Offset(rightBudX - bayRadiusX, caseTop + 4f),
                        size = Size(bayRadiusX * 2, bayRadiusY * 2)
                    )
                }

                // Subtle rim highlight along top edge
                drawPath(
                    path = bodyPath,
                    color = Color.White.copy(alpha = 0.15f),
                    style = Stroke(width = 2.5f)
                )

                // 4. Case LED Status Light
                val ledColor = when {
                    device.caseCharging -> BatteryGreen
                    device.caseBattery > 35 -> BatteryGreen
                    device.caseBattery > 15 -> BatteryAmber
                    else -> BatteryRed
                }
                val ledCenterY = caseTop + (caseHeight * 0.45f)

                // Outer LED Glow
                drawCircle(
                    color = ledColor.copy(alpha = 0.35f * ledPulse),
                    radius = 9f,
                    center = Offset(centerX, ledCenterY)
                )
                // LED Core Pin
                drawCircle(
                    color = ledColor,
                    radius = 3.5f,
                    center = Offset(centerX, ledCenterY)
                )

                // 5. Case Lid (animated opening with 3D perspective flip)
                val lidHeight = 76f
                val lidHingeY = caseTop

                // When lid opens: it rotates upward and scales vertically in perspective
                val animatedLidScaleY = 1f - (lidProgress * 1.6f) // flips perspective
                val lidPivotY = lidHingeY

                translate(left = 0f, top = -lidProgress * 32f) {
                    val openAlpha = (1f - lidProgress * 0.7f).coerceIn(0.2f, 1f)
                    val effectiveLidH = (lidHeight * animatedLidScaleY).coerceAtLeast(14f)

                    if (lidProgress < 0.85f) {
                        val lidPath = Path().apply {
                            addRoundRect(
                                RoundRect(
                                    rect = androidx.compose.ui.geometry.Rect(
                                        left = caseLeft,
                                        top = lidPivotY - effectiveLidH,
                                        right = caseLeft + caseWidth,
                                        bottom = lidPivotY
                                    ),
                                    topLeft = CornerRadius(44f, 44f),
                                    topRight = CornerRadius(44f, 44f),
                                    bottomLeft = CornerRadius(12f, 12f),
                                    bottomRight = CornerRadius(12f, 12f)
                                )
                            )
                        }

                        drawPath(
                            path = lidPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    caseAccentColor.copy(alpha = openAlpha),
                                    caseBaseColor.copy(alpha = openAlpha)
                                ),
                                startY = lidPivotY - effectiveLidH,
                                endY = lidPivotY
                            )
                        )
                        drawPath(
                            path = lidPath,
                            color = Color.White.copy(alpha = 0.20f * openAlpha),
                            style = Stroke(width = 2f)
                        )
                    } else {
                        // Open lid resting in back
                        val openLidPath = Path().apply {
                            addRoundRect(
                                RoundRect(
                                    rect = androidx.compose.ui.geometry.Rect(
                                        left = caseLeft + 6f,
                                        top = lidPivotY - 50f,
                                        right = caseLeft + caseWidth - 6f,
                                        bottom = lidPivotY - 6f
                                    ),
                                    topLeft = CornerRadius(36f, 36f),
                                    topRight = CornerRadius(36f, 36f),
                                    bottomLeft = CornerRadius(14f, 14f),
                                    bottomRight = CornerRadius(14f, 14f)
                                )
                            )
                        }
                        drawPath(
                            path = openLidPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    caseBaseColor.copy(alpha = 0.6f),
                                    caseAccentColor.copy(alpha = 0.85f)
                                )
                            )
                        )
                    }
                }
            }
        }

        // Interactive Action Hints / Earbud Toggles
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                onClick = onToggleLeftEarbud,
                shape = RoundedCornerShape(12.dp),
                color = if (device.isLeftInEar) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.testTag("toggle_left_earbud_btn")
            ) {
                Text(
                    text = if (device.isLeftInEar) "L: In Ear" else "L: In Case",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = if (device.isLeftInEar) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Surface(
                onClick = onToggleCase,
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.testTag("toggle_case_lid_btn")
            ) {
                Text(
                    text = if (isOpen) "Tap: Close Lid" else "Tap: Open Lid",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Surface(
                onClick = onToggleRightEarbud,
                shape = RoundedCornerShape(12.dp),
                color = if (device.isRightInEar) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.testTag("toggle_right_earbud_btn")
            ) {
                Text(
                    text = if (device.isRightInEar) "R: In Ear" else "R: In Case",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = if (device.isRightInEar) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

private fun DrawScope.drawSingleEarbud(
    centerX: Float,
    centerY: Float,
    isLeft: Boolean,
    modelType: TwsModelType,
    bodyColor: Color,
    accentColor: Color,
    isCharging: Boolean
) {
    when (modelType) {
        TwsModelType.STEM_WHITE, TwsModelType.TRANSPARENT_GLAS, TwsModelType.NEON_CYAN -> {
            // Stem style bud (like AirPods Pro or Nothing Ear)
            val stemWidth = 14f
            val stemHeight = 46f
            val headRadius = 18f
            val headCenter = Offset(centerX + (if (isLeft) -4f else 4f), centerY - 14f)

            // Bud head (bulb)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(bodyColor, accentColor),
                    center = headCenter,
                    radius = headRadius
                ),
                radius = headRadius,
                center = headCenter
            )

            // Silicone ear tip
            val tipX = headCenter.x + (if (isLeft) -11f else 11f)
            drawOval(
                color = if (modelType == TwsModelType.NEON_CYAN) CyanPrimary else Color(0xFFD1D5DB),
                topLeft = Offset(tipX - 6f, headCenter.y - 7f),
                size = Size(12f, 14f)
            )

            // Acoustic Mesh Grille
            drawOval(
                color = Color(0xFF1F2937),
                topLeft = Offset(headCenter.x - 3.5f, headCenter.y - 4f),
                size = Size(7f, 8f)
            )

            // Stem body
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(bodyColor, accentColor),
                    startY = centerY - 12f,
                    endY = centerY + stemHeight
                ),
                topLeft = Offset(centerX - (stemWidth / 2f), centerY - 12f),
                size = Size(stemWidth, stemHeight),
                cornerRadius = CornerRadius(6f, 6f)
            )

            // Chrome charging contacts at stem base
            drawRoundRect(
                color = if (isCharging) CyanPrimary else Color(0xFF9CA3AF),
                topLeft = Offset(centerX - (stemWidth / 2f), centerY + stemHeight - 6f),
                size = Size(stemWidth, 6f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Microphone slit on stem
            drawRoundRect(
                color = Color(0xFF111827),
                topLeft = Offset(centerX - 1.5f, centerY + 10f),
                size = Size(3f, 9f),
                cornerRadius = CornerRadius(1.5f, 1.5f)
            )
        }

        TwsModelType.IN_EAR_ROUND_DARK, TwsModelType.GRAPHITE_OVAL -> {
            // Rounded in-ear bud (Galaxy Buds / Pixel Buds style)
            val bulbRadiusX = 22f
            val bulbRadiusY = 26f
            val budCenter = Offset(centerX, centerY)

            // Main oval capsule
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(accentColor, bodyColor),
                    center = Offset(budCenter.x - 4f, budCenter.y - 6f),
                    radius = bulbRadiusY
                ),
                topLeft = Offset(budCenter.x - bulbRadiusX, budCenter.y - bulbRadiusY),
                size = Size(bulbRadiusX * 2, bulbRadiusY * 2)
            )

            // Capacitive touch sensor pad
            drawOval(
                color = Color.White.copy(alpha = 0.08f),
                topLeft = Offset(budCenter.x - (bulbRadiusX * 0.55f), budCenter.y - (bulbRadiusY * 0.55f)),
                size = Size(bulbRadiusX * 1.1f, bulbRadiusY * 1.1f)
            )

            // Dual mic dots
            drawCircle(
                color = Color(0xFF0F172A),
                radius = 2.5f,
                center = Offset(budCenter.x - 8f, budCenter.y - 12f)
            )
            drawCircle(
                color = Color(0xFF0F172A),
                radius = 2.5f,
                center = Offset(budCenter.x + 8f, budCenter.y - 12f)
            )
        }
    }
}

private data class ModelColorTheme(
    val caseBaseColor: Color,
    val caseAccentColor: Color,
    val budBodyColor: Color,
    val budAccentColor: Color
)

private fun getDeviceColors(modelType: TwsModelType): ModelColorTheme {
    return when (modelType) {
        TwsModelType.STEM_WHITE -> ModelColorTheme(
            caseBaseColor = Color(0xFFE5E7EB),
            caseAccentColor = Color(0xFFFFFFFF),
            budBodyColor = Color(0xFFFFFFFF),
            budAccentColor = Color(0xFFE5E7EB)
        )
        TwsModelType.IN_EAR_ROUND_DARK -> ModelColorTheme(
            caseBaseColor = Color(0xFF181E29),
            caseAccentColor = Color(0xFF283344),
            budBodyColor = Color(0xFF1E2634),
            budAccentColor = Color(0xFF334155)
        )
        TwsModelType.NEON_CYAN -> ModelColorTheme(
            caseBaseColor = Color(0xFF0C1929),
            caseAccentColor = Color(0xFF0D334D),
            budBodyColor = Color(0xFF0F2B3E),
            budAccentColor = Color(0xFF00E5FF)
        )
        TwsModelType.TRANSPARENT_GLAS -> ModelColorTheme(
            caseBaseColor = Color(0xFF202630),
            caseAccentColor = Color(0xFF374151),
            budBodyColor = Color(0xFFE2E8F0),
            budAccentColor = Color(0xFF94A3B8)
        )
        TwsModelType.GRAPHITE_OVAL -> ModelColorTheme(
            caseBaseColor = Color(0xFF27272A),
            caseAccentColor = Color(0xFF3F3F46),
            budBodyColor = Color(0xFF3F3F46),
            budAccentColor = Color(0xFF52525B)
        )
    }
}
