package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BatteryAmber
import com.example.ui.theme.BatteryChargingCyan
import com.example.ui.theme.BatteryGreen
import com.example.ui.theme.BatteryRed

@Composable
fun getBatteryColor(level: Int, isCharging: Boolean): Color {
    return when {
        isCharging -> BatteryChargingCyan
        level > 40 -> BatteryGreen
        level > 20 -> BatteryAmber
        else -> BatteryRed
    }
}

/**
 * Circular interactive battery gauge with glow and charging indicator
 */
@Composable
fun TwsCircularBatteryGauge(
    level: Int,
    isCharging: Boolean,
    label: String,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    strokeWidth: Dp = 6.dp
) {
    val animatedProgress by animateFloatAsState(
        targetValue = (level.coerceIn(0, 100)) / 100f,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "batteryProgress"
    )

    val targetColor = getBatteryColor(level, isCharging)
    val animatedColor by animateColorAsState(
        targetValue = targetColor,
        animationSpec = tween(durationMillis = 400),
        label = "batteryColor"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = if (isCharging || level <= 20) 0.6f else 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier.testTag("battery_gauge_$label"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(size)
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val strokePx = strokeWidth.toPx()
                val radius = (this.size.minDimension - strokePx) / 2f
                val centerOffset = Offset(this.size.width / 2f, this.size.height / 2f)

                // Background track
                drawCircle(
                    color = Color.White.copy(alpha = 0.10f),
                    radius = radius,
                    center = centerOffset,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )

                // Outer ambient glow if charging or low
                if (isCharging || level <= 20) {
                    drawCircle(
                        color = animatedColor.copy(alpha = 0.18f * pulseAlpha),
                        radius = radius + strokePx * 0.8f,
                        center = centerOffset,
                        style = Stroke(width = strokePx * 1.5f)
                    )
                }

                // Active progress arc starting from top (-90 degrees)
                val sweep = 360f * animatedProgress
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            animatedColor.copy(alpha = 0.75f),
                            animatedColor,
                            animatedColor
                        ),
                        center = centerOffset
                    ),
                    startAngle = -90f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = Offset(centerOffset.x - radius, centerOffset.y - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            // Center Content: percentage and charging lightning icon
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (isCharging) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Charging",
                        tint = animatedColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = "$level%",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = if (size > 60.dp) 14.sp else 12.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * Compact horizontal battery badge with animated progress bar
 */
@Composable
fun TwsBatteryBarPill(
    level: Int,
    isCharging: Boolean,
    label: String,
    modifier: Modifier = Modifier
) {
    val batteryColor = getBatteryColor(level, isCharging)

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(8.dp))

        // Mini bar
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(7.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.White.copy(alpha = 0.12f))
        ) {
            Box(
                modifier = Modifier
                    .width(44.dp * (level.coerceIn(0, 100) / 100f))
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(batteryColor)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))
        if (isCharging) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Charging",
                tint = batteryColor,
                modifier = Modifier.size(14.dp)
            )
        }
        Text(
            text = "$level%",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = batteryColor
        )
    }
}
