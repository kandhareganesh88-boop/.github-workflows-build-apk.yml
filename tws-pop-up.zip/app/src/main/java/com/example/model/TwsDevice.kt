package com.example.model

enum class TwsModelType(val displayName: String, val brand: String) {
    STEM_WHITE("White Stem Pro", "Pod Design"),
    IN_EAR_ROUND_DARK("Matte Charcoal", "Pro Sound"),
    NEON_CYAN("Cyber Cyan Buds", "Gaming Edition"),
    TRANSPARENT_GLAS("Clear Sound Edition", "Transparent Tech"),
    GRAPHITE_OVAL("Graphite Oval", "Studio Series")
}

enum class AncMode(val title: String, val subtitle: String) {
    ANC("Noise Cancelling", "Blocks ambient sound"),
    OFF("Off", "Passive isolation"),
    TRANSPARENCY("Transparency", "Hear natural surroundings")
}

data class TwsDevice(
    val id: String,
    val name: String,
    val modelType: TwsModelType = TwsModelType.STEM_WHITE,
    val leftBattery: Int = 88,
    val leftCharging: Boolean = false,
    val rightBattery: Int = 85,
    val rightCharging: Boolean = false,
    val caseBattery: Int = 74,
    val caseCharging: Boolean = true,
    val isCaseOpen: Boolean = true,
    val isLeftInEar: Boolean = false,
    val isRightInEar: Boolean = false,
    val isConnected: Boolean = true,
    val isPaired: Boolean = true,
    val rssi: Int = -48,
    val ancMode: AncMode = AncMode.ANC,
    val eqPreset: String = "Balanced",
    val macAddress: String = "AA:BB:CC:DD:EE:01",
    val isFindingChirpActive: Boolean = false
) {
    val averageEarbudsBattery: Int
        get() = (leftBattery + rightBattery) / 2

    val hasLowBattery: Boolean
        get() = leftBattery < 20 || rightBattery < 20 || caseBattery < 20
}
