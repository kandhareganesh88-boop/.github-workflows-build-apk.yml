package com.example.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.model.AncMode
import com.example.model.TwsDevice
import com.example.model.TwsModelType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TwsBluetoothManager(private val context: Context) {

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _discoveredDevices = MutableStateFlow<List<TwsDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<TwsDevice>> = _discoveredDevices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _bluetoothEnabled = MutableStateFlow(bluetoothAdapter?.isEnabled == true)
    val bluetoothEnabled: StateFlow<Boolean> = _bluetoothEnabled.asStateFlow()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED") {
                val level = intent.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1)
                @Suppress("DEPRECATION")
                val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                if (device != null && level >= 0) {
                    updateDeviceBattery(device.address, level)
                }
            } else if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                _bluetoothEnabled.value = (state == BluetoothAdapter.STATE_ON)
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(batteryReceiver, filter)
            }
        } catch (_: Exception) {}
        loadDefaultSimulatedDevices()
    }

    fun hasBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun refreshDevices() {
        _bluetoothEnabled.value = bluetoothAdapter?.isEnabled == true
        val realDevices = mutableListOf<TwsDevice>()

        if (hasBluetoothPermissions() && bluetoothAdapter?.isEnabled == true) {
            try {
                bluetoothAdapter.bondedDevices?.forEach { device ->
                    val name = device.name ?: "Wireless Audio"
                    val address = device.address
                    val battery = getDeviceBatteryLevel(device)
                    val isTws = isLikelyTwsName(name)
                    if (isTws || realDevices.isEmpty()) {
                        val modelType = mapNameToModelType(name)
                        realDevices.add(
                            TwsDevice(
                                id = address,
                                name = name,
                                modelType = modelType,
                                leftBattery = if (battery in 1..100) battery else 88,
                                leftCharging = false,
                                rightBattery = if (battery in 1..100) (battery - 2).coerceAtLeast(5) else 85,
                                rightCharging = false,
                                caseBattery = if (battery in 1..100) (battery + 10).coerceAtMost(100) else 75,
                                caseCharging = true,
                                isConnected = true,
                                isPaired = true,
                                rssi = -42,
                                macAddress = address
                            )
                        )
                    }
                }
            } catch (_: Exception) {}
        }

        // Merge real devices with rich interactive simulated models so user can always explore
        val merged = (realDevices + getSimulatedFastPairDevices()).distinctBy { it.name }
        _discoveredDevices.value = merged
    }

    private fun loadDefaultSimulatedDevices() {
        _discoveredDevices.value = getSimulatedFastPairDevices()
    }

    fun getSimulatedFastPairDevices(): List<TwsDevice> {
        return listOf(
            TwsDevice(
                id = "SIM-PODS-PRO",
                name = "AirPods Pro (2nd Gen)",
                modelType = TwsModelType.STEM_WHITE,
                leftBattery = 92,
                leftCharging = false,
                rightBattery = 90,
                rightCharging = false,
                caseBattery = 84,
                caseCharging = false,
                isCaseOpen = true,
                isLeftInEar = false,
                isRightInEar = false,
                isConnected = false,
                isPaired = false,
                rssi = -38,
                ancMode = AncMode.ANC,
                eqPreset = "Spatial Audio"
            ),
            TwsDevice(
                id = "SIM-PIXEL-BUDS",
                name = "Google Pixel Buds Pro",
                modelType = TwsModelType.IN_EAR_ROUND_DARK,
                leftBattery = 78,
                leftCharging = true,
                rightBattery = 76,
                rightCharging = true,
                caseBattery = 65,
                caseCharging = true,
                isCaseOpen = true,
                isLeftInEar = false,
                isRightInEar = false,
                isConnected = false,
                isPaired = false,
                rssi = -44,
                ancMode = AncMode.TRANSPARENCY,
                eqPreset = "Balanced"
            ),
            TwsDevice(
                id = "SIM-NOTHING-EAR",
                name = "Nothing Ear (2) Transparent",
                modelType = TwsModelType.TRANSPARENT_GLAS,
                leftBattery = 64,
                leftCharging = false,
                rightBattery = 62,
                rightCharging = false,
                caseBattery = 50,
                caseCharging = false,
                isCaseOpen = true,
                isLeftInEar = false,
                isRightInEar = false,
                isConnected = false,
                isPaired = false,
                rssi = -52,
                ancMode = AncMode.ANC,
                eqPreset = "Bass Boost"
            ),
            TwsDevice(
                id = "SIM-GALAXY-BUDS",
                name = "Galaxy Buds2 Pro",
                modelType = TwsModelType.GRAPHITE_OVAL,
                leftBattery = 45,
                leftCharging = true,
                rightBattery = 42,
                rightCharging = true,
                caseBattery = 35,
                caseCharging = true,
                isCaseOpen = true,
                isLeftInEar = false,
                isRightInEar = false,
                isConnected = false,
                isPaired = false,
                rssi = -55,
                ancMode = AncMode.OFF,
                eqPreset = "Vocal Clarity"
            ),
            TwsDevice(
                id = "SIM-CYBER-NEON",
                name = "Cyber Gaming TWS Ultra",
                modelType = TwsModelType.NEON_CYAN,
                leftBattery = 18, // Low battery demonstration
                leftCharging = false,
                rightBattery = 15,
                rightCharging = false,
                caseBattery = 28,
                caseCharging = false,
                isCaseOpen = true,
                isLeftInEar = false,
                isRightInEar = false,
                isConnected = false,
                isPaired = false,
                rssi = -60,
                ancMode = AncMode.ANC,
                eqPreset = "Ultra Bass"
            )
        )
    }

    private fun getDeviceBatteryLevel(device: BluetoothDevice): Int {
        return try {
            val method = device.javaClass.getMethod("getBatteryLevel")
            val result = method.invoke(device) as? Int
            result ?: -1
        } catch (_: Exception) {
            -1
        }
    }

    private fun isLikelyTwsName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("buds") || lower.contains("pods") || lower.contains("airpod") ||
                lower.contains("ear") || lower.contains("headset") || lower.contains("tws") ||
                lower.contains("wireless") || lower.contains("sony") || lower.contains("bose")
    }

    private fun mapNameToModelType(name: String): TwsModelType {
        val lower = name.lowercase()
        return when {
            lower.contains("airpod") || lower.contains("stem") -> TwsModelType.STEM_WHITE
            lower.contains("nothing") || lower.contains("clear") -> TwsModelType.TRANSPARENT_GLAS
            lower.contains("pixel") || lower.contains("round") -> TwsModelType.IN_EAR_ROUND_DARK
            lower.contains("cyber") || lower.contains("game") -> TwsModelType.NEON_CYAN
            else -> TwsModelType.GRAPHITE_OVAL
        }
    }

    private fun updateDeviceBattery(address: String, batteryLevel: Int) {
        val current = _discoveredDevices.value.toMutableList()
        val index = current.indexOfFirst { it.macAddress.equals(address, ignoreCase = true) }
        if (index != -1) {
            val old = current[index]
            current[index] = old.copy(
                leftBattery = batteryLevel,
                rightBattery = (batteryLevel - 2).coerceAtLeast(5)
            )
            _discoveredDevices.value = current
        }
    }

    fun cleanUp() {
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {}
    }
}
