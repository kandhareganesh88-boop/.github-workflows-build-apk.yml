package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.AncMode
import com.example.model.TwsDevice
import com.example.model.TwsModelType

@Entity(tableName = "paired_tws_devices")
data class TwsDeviceEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val modelTypeName: String,
    val leftBattery: Int,
    val leftCharging: Boolean,
    val rightBattery: Int,
    val rightCharging: Boolean,
    val caseBattery: Int,
    val caseCharging: Boolean,
    val isConnected: Boolean,
    val ancModeName: String,
    val eqPreset: String,
    val lastConnectedTime: Long = System.currentTimeMillis()
) {
    fun toDomain(): TwsDevice {
        val modelType = try {
            TwsModelType.valueOf(modelTypeName)
        } catch (_: Exception) {
            TwsModelType.STEM_WHITE
        }
        val ancMode = try {
            AncMode.valueOf(ancModeName)
        } catch (_: Exception) {
            AncMode.ANC
        }
        return TwsDevice(
            id = id,
            name = name,
            modelType = modelType,
            leftBattery = leftBattery,
            leftCharging = leftCharging,
            rightBattery = rightBattery,
            rightCharging = rightCharging,
            caseBattery = caseBattery,
            caseCharging = caseCharging,
            isConnected = isConnected,
            isPaired = true,
            ancMode = ancMode,
            eqPreset = eqPreset
        )
    }

    companion object {
        fun fromDomain(device: TwsDevice): TwsDeviceEntity {
            return TwsDeviceEntity(
                id = device.id,
                name = device.name,
                modelTypeName = device.modelType.name,
                leftBattery = device.leftBattery,
                leftCharging = device.leftCharging,
                rightBattery = device.rightBattery,
                rightCharging = device.rightCharging,
                caseBattery = device.caseBattery,
                caseCharging = device.caseCharging,
                isConnected = device.isConnected,
                ancModeName = device.ancMode.name,
                eqPreset = device.eqPreset,
                lastConnectedTime = System.currentTimeMillis()
            )
        }
    }
}
