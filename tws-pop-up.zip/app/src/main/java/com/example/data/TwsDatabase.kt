package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [TwsDeviceEntity::class], version = 1, exportSchema = false)
abstract class TwsDatabase : RoomDatabase() {
    abstract fun twsDao(): TwsDao

    companion object {
        @Volatile
        private var INSTANCE: TwsDatabase? = null

        fun getDatabase(context: Context): TwsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TwsDatabase::class.java,
                    "tws_app_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
