package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TwsDao {
    @Query("SELECT * FROM paired_tws_devices ORDER BY lastConnectedTime DESC")
    fun getAllPairedDevices(): Flow<List<TwsDeviceEntity>>

    @Query("SELECT * FROM paired_tws_devices WHERE id = :deviceId LIMIT 1")
    suspend fun getDeviceById(deviceId: String): TwsDeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDevice(device: TwsDeviceEntity)

    @Update
    suspend fun updateDevice(device: TwsDeviceEntity)

    @Query("DELETE FROM paired_tws_devices WHERE id = :deviceId")
    suspend fun deleteDevice(deviceId: String)
}
